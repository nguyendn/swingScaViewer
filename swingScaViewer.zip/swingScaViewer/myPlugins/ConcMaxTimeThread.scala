/*Copyright 2012 Jean-Louis PASTUREL 
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*  you may not use this file except in compliance with the License.
*  You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*  distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*  limitations under the License.
*/
class ConcMaxTimeThread {
def metInit(tab:Array[String]=null) {
    // To reinitialise static variable if necessary
    // Nothing to do
  }
  def retour(tabStr: Array[String]): Double =
    {
    
		

		var enr = tabStr(0)
		// System.out.println("enr ="+enr);
		// System.out.println("regexp="+tabString[1]);
		// Motif du Time+
		val pat = "\\s\\d+\\:\\d+\\.\\d+\\s+".r
		
		var match0 = pat.findFirstIn(enr)
		

		var ext1="";
		var timePlus=0L;
		while (None != match0) {
			ext1 = match0.get.trim
			enr = enr.substring(enr.indexOf(ext1) + ext1.length());
			//System.out.println("Max ext1="+ext1);
			val  tabStr:Array[String]=ext1.split("\\:");
			var lg:Long=(tabStr(0).trim().toLong)*60+(tabStr(1).split("\\.")(0).trim()).toLong
			if(lg>timePlus)timePlus=lg;

			match0 = pat.findFirstIn(enr)
		
		}

		timePlus.toDouble
	
    
    
    }
}